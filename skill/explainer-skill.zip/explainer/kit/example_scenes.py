"""Two fictional example scenes. Copy the pattern: each function returns dict(title, narr, say, aud, svg)."""
from engine import *

def e1():
    v = Person(90, 270, 'A customer', s=0)
    v += Gp(Bub(40, 90, '"Where is my order?"', 24), s=0)
    v += Ln(170, 260, 340, 250, INK, 4, True, s=1)
    v += Gp(Card(350, 170, 280, 160, 'AI model', 'reads and writes'), s=1)
    v += Gp(R(690, 170, 240, 160, '#fff', GREY, 4, 14, '10 8') + T(810, 235, 'The orders list', 26, GREY, 'middle', 700) + T(810, 270, 'not in its head', 20, GREY, 'middle'), s=2)
    v += Cap('A model only knows what it was given.', s=3, y=555)
    narr = ['A customer asks a shop assistant: where is my order?',
            'An AI model reads and writes. It turns words into words.',
            'The orders list is not in its head. It was never shown it.',
            'So a model only knows what it was given. To answer well it needs a way to look.']
    say = ['A customer asks: where is my order?',
           'The model reads and writes. That is all it does.',
           'The orders list is not in its head.',
           'A model only knows what it was given. It needs a way to look.']
    aud = dict(exec='A bare chatbot cannot see your information, and it can guess.',
               sec='A model alone has no access and no accountability.',
               ops='First building block: the model deployment.')
    return dict(title='Start here: a model on its own', narr=narr, say=say, aud=aud, svg=v)

def e2():
    v = Gp(Card(30, 190, 220, 120, 'AI model', 'asks'), s=0)
    v += Gp(Card(370, 190, 220, 120, 'A tool', 'one small job'), s=1)
    v += Gp(R(710, 190, 220, 120, '#fff', INK, 4, 14) + T(820, 238, 'Orders list', 26, INK, 'middle', 700) + T(820, 272, 'Order 42: shipped', 17, GREY, 'middle'), s=0)
    v += Gp(Ln(250, 235, 370, 235, INK, 4, True) + Tag(256, 170, 'order 42?', 19), s=2)
    v += Gp(Ln(590, 235, 710, 235, INK, 4, True) + Tag(596, 170, 'look it up', 19), s=3)
    v += Gp(R(30, 380, 900, 80, '#fff', INK, 4, 14) + T(480, 430, '"Order 42 has shipped."', 26, INK, 'middle', 700), s=4)
    narr = ['Give the model hands. It can ask a tool.',
            'A tool does one small job.',
            'The model asks the tool a question.',
            'The tool looks in the orders list.',
            'Now the answer comes from the list, not from a guess.']
    say = ['Give the model hands.', 'A tool does one small job.', 'The model asks the tool.',
           'The tool looks in the orders list.', 'The answer comes from the list, not a guess.']
    aud = dict(exec='Answers come from your data, not from a guess.',
               sec='Each tool is a door. Decide who may use it.',
               ops='One tool, one job, one owner.')
    return dict(title='Give it hands: a tool', narr=narr, say=say, aud=aud, svg=v)

SCENES = [e1, e2]
