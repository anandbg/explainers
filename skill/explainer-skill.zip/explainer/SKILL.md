---
name: explainer
description: "A bottom-up animated explainer: one self-contained HTML file with step-by-step SVG animations, a plain explanation, a red 'Say this' box with the exact words to speak, a 'Tailor it for your room' panel (executive, security, operations) and a rehearsal quiz. Use when the user says 'explainer', 'make the explainer', 'explain this hyper intuitively bottoms up', 'step by step animations so I really understand', or 'share a html' for a topic or project."
---

# Explainer

The original prompt: "explain this hyper intuitively bottoms up with the most simple step by step animations so i really understand concretely", then "share a html".

## The bottom-up rule
- Start with the smallest working piece (a model on its own, a single tool).
- Add ONE idea per step.
- Open each step with the problem the last step left. Append "Next problem: ..." to the last beat via BRIDGE.
- Put the whole picture together near the end, then attacks or failure cases, cost, what is proven, what is not yet, and what each audience takes away.
- If two steps can swap places, it is a list, not a build. Reorder.

## Method
1. Gather facts from primary files only (docs, evidence, code). Mark preview features, made-up data and "my reading" items. Do not invent numbers. State measured figures with how they were measured.
2. Outline 12 to 18 steps, each answering one question.
3. Copy the kit: `mkdir -p <topic>/explainer-html && cp <this skill folder>/kit/* <topic>/explainer-html/`. 
4. Write `scenes_<topic>.py`. Each scene function returns `dict(title, narr, say, aud, svg)`:
   - svg: built from engine.py helpers (T, TL, R, Gp, Ln, Box, Bub, Person, Key, Lock, Doc, Cap, Card, Tag). Viewbox is 960 wide by about 600 tall. Beats use `s=` (first beat shown) and `e=` (first beat hidden). Beat 0 is visible from the start.
   - narr: plain explanation, one per beat.
   - say: the words to speak, one per beat, 8 to 20 words. `len(say) == len(narr)` (build.py asserts).
   - aud: dict(exec=, sec=, ops=) one line each.
   - See `kit/example_scenes.py` for two finished scenes (fictional).
5. Edit CONFIG at the top of `build.py` (TITLE, BRAND, OUT, ORDER, BRIDGE, QS, INTRO_PARAS). Quiz: 6 to 8 questions, answers rotate automatically.
6. Build: `/usr/bin/python3 build.py` (Pillow and other libs live on the system Python).
7. Check: `./shot.sh "$PWD/<out>.html" <scene> <beat> /tmp/x.png` for the last beat of every step, then OPEN each image and look for overflow, overlap and clipped text. Exit 0 proves nothing visual. Call shot.sh with explicit arguments.
8. Fix, rebuild and give the user the finished HTML file.

## The Say box is a story, not a caption 
- Each step gets one small story told across its beats: a generic person or agent ("a customer", "a team", "an agent", never a named character), one want, one thing that goes wrong, one fix.
- The exam or product term arrives last, as the name for what just happened. The listener should be able to repeat it to someone else.
- End the step with one plain line: the answer to carry into the exam or the room.
- Few words. Lines still align one per beat, so each beat moves the story one step.

## Voice
- Humanizer rules: short plain sentences, "I" not "we", no em dashes, no emoji, no not-X-but-Y.
- Teach from zero. Plain word first, then the proper term. Never an unexplained acronym.
- In the file, "Say this" is first person. Tell the user which claims say "I built/tested" so they can change them.
- Fictional data only in examples and labs. Run copy in the speaker's name past a second reviewer.

