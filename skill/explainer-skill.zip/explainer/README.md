# Explainer skill

A Claude Code skill that turns a topic into one self-contained animated HTML explainer: step-by-step SVG animations, a plain explanation, a "Say this" box, audience notes and a quiz.

## Install
1. Unzip `explainer-skill.zip`.
2. Put the `explainer` folder in `~/.claude/skills/`.
3. Start Claude Code and ask: "make an explainer on <topic>".

## Try the kit by hand
```
cd explainer/kit
python3 build.py        # writes explainer.html from example_scenes.py (fictional)
./shot.sh "$PWD/explainer.html" 1 4 /tmp/x.png   # screenshot step 1, beat 4 (needs Google Chrome on macOS)
```
Needs Python 3 only. The shot script needs Chrome.

The example scenes use fictional data. Replace them with your own scenes, then edit CONFIG at the top of `kit/build.py`.
